// ⚠️ Preencha com as credenciais do SEU projeto Firebase.
// Veja o passo a passo no README.md ("1. Criar o projeto no Firebase").
export const firebaseConfig = {
  apiKey: "SUA_API_KEY",
  authDomain: "SEU_PROJETO.firebaseapp.com",
  projectId: "SEU_PROJETO",
  storageBucket: "SEU_PROJETO.appspot.com",
  messagingSenderId: "SEU_SENDER_ID",
  appId: "SEU_APP_ID"
};

// ⚠️ Coloque aqui os e-mails do Google dos PAIS (quem pode cadastrar presentes).
// Precisa ser EXATAMENTE igual ao e-mail usado no login do Google.
export const ADMIN_EMAILS = [
  "mae.do.angelo@gmail.com",
  "pai.do.angelo@gmail.com"
];
